This is a movieflix repository.  
Uses:  
1) index.html is the main page of the movieflix  
2) From the index page you can see all the content, to see only movies select the movies button on the top. Similarly for the series.      
3) To login/register use the login button. Clicking the sign in button redirects to the user.html page  
4) Sort by button helps in sorting the movies based on the imdb rating, imdb votes, year of release and in the alphabetical order.  
5) To see the details of a movie such as imdb rating and the plot, you can hover on to the movie image.  
6) To open the imdb page of the movie, click on the movie title.  
7) To see the user comments and the user ratings, click the thubmnail image of the movie  
###ADMIN access###
1) go to index.html#/admin to access the admin page  
2) Admin can edit/ delete or add a new title.  
3) For adding a new title, click the add button on the screen and provide the movie details.  
4) For editing/ deleting the existing movie from the list, hover on to the movie thumbnail and click the edit button. You can either modify the existing movie or delete the movie from the list.  
