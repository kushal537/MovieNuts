We have used IMDBPYSQL to import the database. you don't need it we have attached the database backup.
1) use npm install command in this directory to install dependencies
2) after installing all the dependencies run project using npm start
3) database used is mysql with username root and password mysql and db imdb_full
4) for any changes use update the database connections in routes/index.js
5) after importing database and running nodejs you can check http://localhost:3000/#/analysis