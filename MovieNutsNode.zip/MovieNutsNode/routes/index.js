var express = require('express');
var router = express.Router();

var mysql = require("mysql");

// First you need to create a connection to the db
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mysql",
  database: "imdb_full"
});

var isConnected = false;

var rating_vs_year_query = 'select year as x, avg(rating) as y from (select d.title, d.production_year as year ,e.info as rating,f.info as genere, b.role,a.person_id,a.movie_id,a.note,c.name from cast_info a, role_type b, name c, title d, movie_info_idx e,movie_info f where person_id=? and role_id = b.id and c.id = a.person_id and b.id  between 1 and 2 and d.id = a.movie_id and d.kind_id=1 and e.info_type_id=101 and e.movie_id = a.movie_id  and  f.info_type_id = 3 and f.movie_id = a.movie_id order by d.production_year )a group by 1 order by 1';
var rating_vs_genere = 'select genere as x, avg(rating) as y from (select d.title, d.production_year as year ,e.info as rating,f.info as genere, b.role,a.person_id,a.movie_id,a.note,c.name from cast_info a, role_type b, name c, title d, movie_info_idx e,movie_info f where person_id=? and role_id = b.id and c.id = a.person_id and b.id  between 1 and 2 and d.id = a.movie_id and d.kind_id=1 and e.info_type_id=101 and e.movie_id = a.movie_id  and  f.info_type_id = 3 and f.movie_id = a.movie_id order by d.production_year )a group by 1 order by 1'
var area_chart = 'select count(1) as c,genere as g, year as x, count(1) as y from (select d.title, d.production_year as year ,e.info as rating,f.info as genere, b.role,a.person_id,a.movie_id,a.note,c.name from (select * from cast_info limit 2000000) a, role_type b, name c, title d, movie_info_idx e,movie_info f where  role_id = b.id and c.id = a.person_id and b.id  between 1 and 2 and d.id = a.movie_id and d.kind_id=1 and e.info_type_id=101 and e.movie_id = a.movie_id  and  f.info_type_id = 3 and f.movie_id = a.movie_id order by d.production_year )a group by 2,3 order by 3';
var top_actors = 'select n.id as person_id, name as name from name n, (select count(1),person_id from ( select person_id, movie_id,title from cast_info c inner join title t on (t.id = c.movie_id) and role_id =1 and t.kind_id =1 limit 50000 )a  group by 2 having count(person_id) > 100)ad  where ad.person_id = n.id '

function getConnection(success) {
  if(isConnected){
    success(con);
    return;
  }
  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    success(con);
    isConnected = true;
    console.log('Connection established');
  });
}



/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/analytics/ratingvsyear/:id',function (req, res, next) {
  getConnection(function (connection) {

    connection.query(rating_vs_year_query,req.params.id,function(err,rows){
      if(err) throw err;

      console.log('Data received from Db:\n');
      console.log(rows);
      res.send(JSON.stringify(rows));
    });

  })
  //res.send("hello");
})

router.get('/analytics/genervsrating/:id',function (req, res, next) {
  getConnection(function (connection) {

    connection.query(rating_vs_genere,req.params.id,function(err,rows){
      if(err) throw err;

      console.log('Data received from Db:\n');
      console.log(rows);
      res.send(JSON.stringify(rows));
    });

  })
  //res.send("hello");
})


router.get('/analytics/topactors',function (req, res, next) {
  getConnection(function (connection) {

    connection.query(top_actors,function(err,rows){
      if(err) throw err;

      console.log('Data received from Db:\n');
      console.log(rows);
      var data = JSON.stringify(rows);




      res.send(data);
    });

  })
  //res.send("hello");
})

router.get('/analytics/areachart',function (req, res, next) {
  getConnection(function (connection) {

    connection.query(area_chart,561368,function(err,rows){
      if(err) throw err;

      console.log('Data received from Db:\n');
      console.log(rows);
      var data = JSON.stringify(rows);
      var out = {};
      var years = {};

      rows.forEach(function (r) {

        var g = r.g;
        if(out[g] == undefined){
          out[g] = {};
        }

        years[r.x] = true;
        out[g][r.x] = r.y;

      })

      var keys = Object.keys(out);

      var _years = Object.keys(years);

      keys.forEach(function (k) {
        var o = out[k];
        var temp = o;
        o = [];

        _years.forEach(function (y) {
          if(temp[y]!=undefined){
            o.push([y,temp[y]]);
          }
          else{
            o.push([y,0]);
          }
        })
        out[k] = o;

      })





      var formatted =[];

      keys.forEach(function (k) {

        formatted.push({"key":k,"values":out[k]});
      })



      
      res.send(formatted);
    });

  })
  //res.send("hello");
})
module.exports = router;
